#include <iostream>
using namespace std;
class Employee
{
private:
    int id;
    string name;
public:
    Employee() : id(0), name("") {}
    Employee(int i, string na) : id(i), name(na) {}

    void getdata()
    {
        cout << "Enter id: ";
        cin >> id;
        cout << "Enter person name: ";
        cin >> name;
    }

    void showdata()
    {
        cout << "ID entered by the user: " << id << endl;
        cout << "Name entered by the user: " << name << endl;
    }
};
class Student
{
    private:
        string degree;
    public:
        Student() : degree("") {}
        Student(string de) : degree(de) {}

        void getdata()
        {
            cout << "Enter Degree Title: ";
            cin >> degree;
        }

        void showdata()
        {
            cout << "Degree is: " << degree << endl;
        }
};
class Professor: private Employee, private Student
{
    private:
        int publication;
    public:
        Professor() : Employee(), Student(), publication(0) {}
        Professor(int id, string na, string de, int pub) : Employee(id, na), Student(de), publication(pub) {}

    void getdata()
    {
        Employee::getdata(); // Call base class getdata() to get id and name
        Student::getdata();
        cout << "Enter publication: ";
        cin >> publication;
    }

    void showdata()
    {
        Employee::showdata(); // Call base class showdata() to display id and name
        Student::showdata();
        cout << "Publication entered by the user: " << publication << endl;
    }
};

int main()
{
    Professor p;
    p.getdata();
    p.showdata();

    return 0;
}