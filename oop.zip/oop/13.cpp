/// Member Functions Defined Outside the Class
#include<iostream>
using namespace std;

void getdis( );
void showdis();

class Distance
{
    private:
        int feets;
        float inches;
    public:
        Distance(): feets(0), inches(0.0f) {}
        Distance(int f, float inc): feets(f), inches(inc) {}

        void getdis();
        void showdis();

        /// d1.Adddist(d2);
        Distance Adddist(Distance dd)
        {
            Distance temp;
            temp.feets = feets + dd.feets;
            temp.inches = inches + dd.inches;
            while(temp.inches >= 12)
            {
                temp.inches -= 12;
                temp.feets++;
            }
            return temp;
        }

        ~Distance(){}
};

int main()
{
    Distance d1(2,29.1f),d2;
    d2.getdis();

    cout<<endl;
    d1.showdis();
    d2.showdis();

    Distance d3 = d1.Adddist(d2);
    d3.showdis();

    return 0;
}

void Distance::getdis()
{
    cout<<"Enter feets:";
    cin>>feets;
    cout<<"Enter inches:";
    cin>>inches;
}
void Distance::showdis()
{
    cout<<"DISTANCE : "<<feets<<"\', "<<inches<<"\""<<endl;
}