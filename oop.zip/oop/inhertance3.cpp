#include <iostream>
using namespace std;
class  base
{
private:
    int pribase;

protected:
    int probase;

public:
    int pubbase;
};
class derived: public base
{
  private:
     void priderive1()
    {
       
    }

protected:
    void proderive1()
    {
       

    }

public:
     void pubderive1()
    {

    }
};
class derived2: private base
{
  private:
     void priderive2()
    {
       pubbase=10;
    }

protected:
    void proderive2()
    {
       

    }

public:
     void pubderive2()
    {

    }
};
int main()
{
    derived2  obj1;
    //cin>>obj1.pubbase;
     obj1.
    return 0;
}