#include <iostream>
using namespace std;

class Employee
{
private:
    int id;
    string name;

public:
    Employee() : id(0), name("") {}
    Employee(int i, string na) : id(i), name(na) {}

    void getdata()
    {
        cout << "Enter id: ";
        cin >> id;
        cout << "Enter person name: ";
        cin >> name;
    }

    void showdata()
    {
        cout << "ID entered by the user: " << id << endl;
        cout << "Name entered by the user: " << name << endl;
    }
};

class Manager : public Employee
{
private:
    float dues;
    string title;

public:
    Manager() : Employee(), dues(0.0f), title("") {}
    Manager(int i, string na, float d, string ti) : Employee(i, na), dues(d), title(ti) {}

    void getdata()
    {
        Employee::getdata(); // Call base class getdata() to get id and name
        cout << "Enter title: ";
        cin >> title;
        cout << "Enter dues: ";
        cin >> dues;
    }

    void showdata()
    {
        Employee::showdata(); // Call base class showdata() to display id and name
        cout << "Title is : " << title << endl;
        cout << "Dues is : " << dues << endl;
        cout<<"The id of a employee is "<<id;
    }
};

class Scientist : public Employee
{
private:
    int publication;

public:
    Scientist() : Employee(), publication(0) {}
    Scientist(int i, string na, int pub) : Employee(i, na), publication(pub) {}

    void getdata()
    {
        Employee::getdata(); // Call base class getdata() to get id and name
        cout << "Enter publication: ";
        cin >> publication;
    }

    void showdata()
    {
        Employee::showdata(); // Call base class showdata() to display id and name
        cout << "Publication entered by the user: " << publication << endl;
    }
};
class laborer : public Employee
{
public:
    laborer() : Employee() {}
    laborer(int i, string na) : Employee(i, na) {}
};
int main()
{
    Manager m(11, "Ali", 45765.1f, "Manager");
    Scientist s(23, "Aslam", 45);
    laborer l(23, "Aslam");

    cout << "Manager Data" << endl;
    // m.getdata();
    m.showdata();

    cout << "\nScientist Data" << endl;
    // s.getdata();
    s.showdata();

    cout << "\nlaborer Data" << endl;
   // l.getdata();
    l.showdata();

    return 0;
}