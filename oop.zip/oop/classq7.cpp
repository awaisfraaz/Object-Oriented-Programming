#include <iostream>
#include <string>
using namespace std;
class student
{
private:
    int admno;
    string sname;
    float math;
    float science;
    float english;
    float total;
   float calculatetotal()
    {
        return math + science + english;
    }
   
public:
 

    void takedata()
    {
        cout << "Enter the admission no of student " << endl;
        cin >> admno;
        cout << "Enter the student name" << endl;
        cin >> sname;
        cout << "Enter the math marks " << endl;
        cin >> math;
        cout << "Enter the science marks " << endl;
        cin >> science;
        cout << "Enter the english marks " << endl;
        cin >> english;
    }
    void showdata()
    {
         total = calculatetotal();
        cout << "The admission no  =  " << admno << endl;
        cout << "The name  is  =  " << sname << endl;
        cout << "The maths marks   =  " << math << endl;
        cout << "The science marks   =  " << science << endl;
        cout << "The english marks   =  " << english << endl;
        cout << "The total marks  =  " << total << endl;
    }
};
int main()
{   
    student Ali;
    cout<<"Enter the details for ALi"<<endl;
    Ali.takedata();
    Ali.showdata();
    return 0;
}