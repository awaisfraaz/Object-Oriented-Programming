#include <iostream>
using namespace std;

class A
{
public:
    void function()
    {
        cout<<"I am function"<<endl;
    }
};
class B 
{
    A obj1;
    public:
    void showdata()
    {
        obj1.function();
    }
};

int main()
{
    B obj2;
    obj2.showdata();
    return 0;
}