/// Static Varibale
#include <iostream>
using namespace std;

class Race
{
private:
    int id;
    static int total;

public:
    Race()
    {
        total++;
        id = total;
    }
    void Showid()
    {
        cout << "id is " << id << endl;
        /// cout<<"total is "<<total<<endl;
    }
    static void Showtotal()
    {
        // cout<<"id is "<<id<<endl;
        cout << "total is " << total << endl;
    }
};
int Race::total = 0;

int main()
{

    cout << "The value of static variable is before objects is" << endl;
    Race::Showtotal();

    Race r1, r2, r3;
    cout << "The value of static variable is after objects is" << endl;
    Race::Showtotal();

    r1.Showid();
    r2.Showid();
    r3.Showid();
    cout << endl;
    r1.Showtotal();
    Race r4, r5, r6;
    r6.Showtotal();
    Race r7;
    Race::Showtotal();
    Race r8;
    Race::Showtotal();
    Race r9;
    Race::Showtotal();
    return 0;
}