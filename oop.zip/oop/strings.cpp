#include <iostream>
#include <string.h>

using namespace std;
int main()
{
    char name[] = "awais fraaz";
    char name1[12] = {'a', 'w', 'a', 'i', 's', ' ', 'f', 'r', 'a', 'a', 'z', '\0'};
    cout << "The name is = " << name << endl;
    cout << "The name is = " << name1 << endl;
    char name2[20];
    cin.getline(name2, 20);
    cout << "The name2 is = " << name2 << endl;
    cin.get(name2, 20);
    cout << "The name2 is = " << name2 << endl;
    char name3[50]="My name is ";
    // used to append two strings
    strcat(name3,name1);
    //  used to display strings 
    puts(name3);
    //used to compare srings character by character 
    int t;
    t=strncmp(name,name1,12);
    if (t>0)
    {
        cout<<"The string one is greater"<<endl;
    }
    else if (t==0)
    {
        cout<<"The strings are equal"<<endl;
    }
    else
    {
        cout<<"The string 2 is greater"<<endl;
    } 
    // used to copy one strings character strings to another 
    strcpy();
    // used to find the length of strings excluding null character 
    int length;

    // used to prints reverse orders characters
    //strrev();
    return 0;
}