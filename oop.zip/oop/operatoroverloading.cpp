#include <iostream>
using namespace std;

class Distance
{
private:
    int feets;
    float inches;

public:
    Distance() : feets(0), inches(0.0f) {}
    Distance(int f, float inc) : feets(f), inches(inc) {}

    void getdis();
    void showdis() const;

    /// d3 = d1 + d2;
    Distance operator+(const Distance &dd) const
    {
      //  cout << "operator +" << endl;
        Distance temp;
        temp.feets = feets + dd.feets;
        temp.inches = inches + dd.inches;
        while (temp.inches >= 12)
        {
            temp.inches -= 12;
            temp.feets++;
        }
        return temp;
    }
    /// d3 = d1 - d2;
    Distance operator-(const Distance &dd) const
    {
      //  cout << "operator -" << endl;
        Distance temp;
        temp.feets = feets - dd.feets;
        temp.inches = inches - dd.inches;
        while (temp.inches >= 12)
        {
            temp.inches -= 12;
            temp.feets++;
        }
        return temp;
    }

    Distance operator*(const Distance &dd) const
    {
       // cout << "operator *" << endl;
        Distance temp;
        temp.feets = feets * dd.feets;
        temp.inches = inches * dd.inches;
        while (temp.inches >= 12)
        {
            temp.inches -= 12;
            temp.feets++;
        }
        return temp;
    }

    bool operator>(const Distance &dd) const
    {
        float tfeets1 = feets * inches / 12.0f;
        float tfeets2 = dd.feets * dd.inches / 12.0f;

        return (tfeets1 > tfeets2) ? true : false;
    }
    bool operator<(const Distance &dd) const
    {
        float tfeets1 = feets * inches / 12.0f;
        float tfeets2 = dd.feets * dd.inches / 12.0f;

        return (tfeets1  < tfeets2) ? true : false;
    }

    ~Distance() {}
};

int main()
{
    Distance d1(2, 29.1f), d2(6, 6.6f), d3(3, 1.6f), d4, d5;
   // d4.getdis();

    cout << endl;
    d1.showdis();
    d2.showdis();
    d3.showdis();
    d4.showdis();

    cout << endl;

    d5 = d1 + d2 ;
    d4=d3*d5;
    cout << endl;

    d5.showdis();
    d4.showdis();
    if (d1 > d2)
        cout << "Distance-1 is largest" << endl;
    else if (d1 < d2)
        cout << "Distance-2 is largest" << endl;
    else
        cout << "Both are equals" << endl;

    return 0;
}

void Distance::getdis()
{
    cout << "Enter feets:";
    cin >> feets;
    cout << "Enter inches:";
    cin >> inches;
}
void Distance::showdis() const
{
    cout << "DISTANCE : " << feets << "\', " << inches << "\"" << endl;
}