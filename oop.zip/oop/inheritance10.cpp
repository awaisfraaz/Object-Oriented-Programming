#include <iostream>
using namespace std;
class A
{
public:
    int age;
    void getdata()
    {
        cout << "Enter the age " << endl;
        cin >> age;
    }
};
class B
{
public:
    int weight;
    void getdata()
    {
        cout << "Enter the weight " << endl;
        cin >> weight;
    }
};
class C : public A, public B
{

};
int main()
{
    C a;
    
    a.A::getdata();
    a.B::getdata();
    //cout<<a.age<<endl;
    return 0;
}