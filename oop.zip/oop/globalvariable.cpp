#include<iostream> 
using namespace std;
 const int x=10;
int main()
{   int m=20;
   ///   x=m;
    cout<<"The value of golobal variable is "<<x<<endl;
    return 0;
}