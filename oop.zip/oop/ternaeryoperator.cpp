#include <iostream>
using namespace std;
int main()
{
    int marks;
    cout << "Enter the marks of subject" << endl;
    cin >> marks;
    cout << "Thr result of student is " << (marks > 50 ? "Pass" : "Fail");
    return 0;
}