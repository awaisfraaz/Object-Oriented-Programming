#include <iostream>
using namespace std;

class Distance
{
private:
    int feets;
    float inches;

public:
    Distance() : feets(0), inches(0.0f) {}
    Distance(int f, float inc) : feets(f), inches(inc) {}
    Distance(float tfeets)
    {
        cout << "I am one argument constructer" << endl;
        feets = tfeets;
        inches = (tfeets - feets) * 12;
    }
    void getdis();
    void showdis() const;

    /// d3 = d1 + d2;
    friend Distance operator+(Distance , Distance);
    ~Distance() {}
};

int main()
{
    Distance d1(2, 2.2), d2(1, 1.1), d3;
    //d3=d1+d2;
    //d3 = d1 + 5.91f;
     d3 = 1.1f + 2.2f;

    d3.showdis();

    return 0;
}

void Distance::getdis()
{
    cout << "Enter feets:";
    cin >> feets;
    cout << "Enter inches:";
    cin >> inches;
}
void Distance::showdis() const
{
    cout << "DISTANCE : " << feets << "\', " << inches << "\"" << endl;
}
Distance operator+(Distance dd1, Distance dd2)
{

    Distance temp;
    temp.feets = dd1.feets + dd2.feets;
    temp.inches = dd1.inches + dd2.inches;
    while (temp.inches >= 12)
    {
        temp.inches -= 12;
        temp.feets++;
    }
    return temp;
}