#include <iostream>
using namespace std;
// uranery operator loading
class count
{
private:
    int n;

public:
    count() : n(0) {}
    count(int count) : n(count) {}
    // corrected
    void showdata()
    {
        cout << "The value of n is = " << n << endl;
    }
    void operator++()
    {
        ++n;
    }
    count operator--()
    {
        // count temp;

        // temp.n = n;
        return count(--n);
        // we can also add nameless temporarey
    }
};

int main()
{
    count obj1;
    obj1.showdata();
    ++obj1;
    obj1.showdata();
    --obj1;
    obj1.showdata();
    count obj2;
    obj2 = --obj1;
    obj2.showdata();
    return 0;
}