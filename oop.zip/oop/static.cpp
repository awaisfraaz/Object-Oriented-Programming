/// Static Varibale
#include<iostream>
using namespace std;

class Race
{
    private:
         int id;
         static int total;
    public:
        Race()
        {
            total++;
            id = total;
        }
        void Showid()
        {
            cout<<"id is "<<id<<endl;
            ///cout<<"total is "<<total<<endl;
        }
        static void Showtotal()
        {
           // cout<<"id is "<<id<<endl;
            cout<<"total is "<<total<<endl;
        }
};
int Race::total = 0;

int main()
{
    Race::Showtotal();

    Race r1, r2, r3;
    r1.Showid();
    r2.Showid();
    r3.Showid();
    cout<<endl;
    r1.Showtotal();


    return 0;
}