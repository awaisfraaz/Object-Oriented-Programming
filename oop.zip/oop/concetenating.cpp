#include <iostream>
using namespace std;

class String
{
private:
    string str;

public:
    String() : str("") {}
    String(string s) : str(s) {}

    void getstr()
    {
        cout << "Enter string ";
        cin >> str;
    }
    void showstr() const
    {
        cout << "String is " << str << endl;
    }

    String operator+(const String &ss) const
    {
        string s = str + ss.str;
        return String(s);
    }
    String operator+=(const String &ss)
    {
        str += ss.str;
        return String(str);
    }
    bool operator>(const String &ss) const
    {
        if (str > ss.str)
            return true;
        else
            return false;
    }
};
int main()
{
    String s1, s2;
    s1.getstr();
    cout<<"Enter the name for object two"<<endl;
    s2.getstr();
    cout << endl;
    s1.showstr();
    s2.showstr();

    //  String s3 = s1 + s2;
    // cout<<endl;
    // s3.showstr();
    s1 += s2;
    s1.showstr();
    if (s1 > s2)
    {
        cout << "The object one string is greater" << endl;
    }
    else
    {
        cout << "Thr object two string is greater " << endl;
    }
    return 0;
}