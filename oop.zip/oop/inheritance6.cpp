#include <iostream>
using namespace std;

class employee
{
private:
    int id;
    string name;

public:
    employee()
    {
    }
    employee(int no, string nume) : id(no), name(nume)
    {
    }
    void getdata()
    {
        cout << "Enter id: ";
        cin >> id;
        cout << "Enter employee name: ";
        cin >> name;
    }

    void showdata()
    {
        cout << "ID entered by the user = " << id << endl;
        cout << "Name entered by the user = " << name << endl;
    }
};

class manager : public employee
{
private:
    float dues;
    string title;

public:
    manager()
    {
    }
    manager(int no, string nume, float du, string tatle) : employee(no, nume), dues(du), title(tatle)
    {
    }
    void getdata()
    {
        employee::getdata(); // Call base class getdata() to get id and name
        cout << "Enter dues of the manager: ";
        cin >> dues;
        cout << "Enter title of the manager: ";
        cin >> title;
    }

    void showdata()
    {
        employee::showdata(); // Call base class showdata() to display id and name
        cout << "dues entered by the user =  " << dues << endl;
        cout << "title entered by the user =  " << title << endl;
    }
};

class scientist : public employee
{
private:
    int publication;

public:
    scientist() {}
    scientist(int no, string nume, int pub) : employee(no, nume), publication(pub) {}
    void getdata()
    {
        employee::getdata(); // Call base class getdata() to get id and name
        cout << "Enter publication: ";
        cin >> publication;
    }

    void showdata()
    {
        employee::showdata(); // Call base class showdata() to display id and name
        cout << "Publication entered by the user = " << publication << endl;
    }
};

class laborer : public employee
{
public:
    laborer() : employee() {}
    laborer(int no, string nume) : employee(no, nume) {}
};
class foreman : public laborer
{
private:
    float quotas;

public:
    void getdata()
    {
        laborer::getdata();
        cout << " Enter quotas : ";
        cin >> quotas;
    }
    void putdata()
    {
        laborer::showdata();
        cout << "\n Quotas  enter by  user : " << quotas;
    }
};
int main()
{
    manager m;
    scientist s;
    laborer l;
    foreman f;
    //  cout << "Manager Data" << endl;
    // m.getdata();
    // m.showdata();

    //  cout << "\nScientist Data" << endl;
    // s.getdata();
    //  s.showdata();

    cout << "\nLaborer Data" << endl;
    l.getdata();
    l.showdata();

    cout << "\nforeman data" << endl;
    f.getdata();
    f.putdata();

    return 0;
}