#include <iostream>
#include <string.h>
using namespace std;
class dummy
{
private:
    static float aa;
    char ch[5];

public:
    dummy(int b, char c[])
    {
        aa += b;
        strcpy(ch, c);
    }
    void show()
    {
        cout << (2 * aa - 1) << "\t" << ch << "\t" << endl;
    }
    dummy operator+(dummy ob)
    {
        dummy temp(.5, "IT");
        cout << temp.aa << endl;
        strcpy(temp.ch, ch);
        strcat(temp.ch, ob.ch);
        return temp;
    }
};
float dummy::aa = 1.5;
int main()
{
    dummy obj1(1.1, "CS");
    obj1.show();
    dummy obj2(2.1, "SE");
    dummy obj3 = obj2 + obj1;
    obj3.show();
    return 0;
}
