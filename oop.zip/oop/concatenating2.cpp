#include <iostream>
#include <string.h>
using namespace std;

const int SIZE = 20;
class String
{
private:
    char str[SIZE];

public:
    String() : str("") {}
    String(char s[])
    {
        strcpy(str, s);
    }

    void getstr()
    {
        cout << "Enter string ";
        cin >> str;
    }
    void showstr() const
    {
        cout << "String is " << str << endl;
    }

    String operator+(const String &ss) const
    {
        if (strlen(str) + strlen(ss.str) >= SIZE - 1)
        {
            cout << "String length overflow" << endl;
            exit(1);
        }
        String temp;
        strcpy(temp.str, str);
        strcat(temp.str, ss.str);
        return temp;
    }
    String operator+=(const String &ss)
    {
        if (strlen(str) + strlen(ss.str) >= SIZE - 1)
        {
            cout << "String length overflow" << endl;
            exit(1);
        }
        strcat(str, ss.str);
        return String(str);
    }
    bool operator>(const String &ss) const
    {
        if (strcmp(str, ss.str) > 0)
            return true;
        else
            return false;
    }
    bool operator<(const String &ss) const
    {
        if (strcmp(str, ss.str) < 0)
            return true;
        else
            return false;
    }
};
int main()
{
    String s1, s2;
    s1.getstr();
    cout << "Enter the name for object two" << endl;
    s2.getstr();
    cout << endl;
    s1.showstr();
    s2.showstr();

    String s3 = s1 + s2;
    cout << endl;
    s3.showstr();

    s1 += s2;
    cout << endl;
    s1.showstr();

    if (s1 > s2)
        cout << "S1 is largest string" << endl;
    else if (s1 < s2)
        cout << "S2 is largest string" << endl;
    else
        cout << "Both are equals" << endl;
    return 0;
}