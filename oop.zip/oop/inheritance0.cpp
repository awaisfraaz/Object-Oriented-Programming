#include <iostream>
using namespace std;
class Person
{
private:
    int id;
    string name;

public:
    void getdata()
    {

        cout << "Enter the ID of person" << endl;
        cin >> id;
        cout << "Enter the name of person" << endl;
        cin >> name;
    }
    void showdaata()
    {

        cout << "The ID of person is = " << id << endl;
        cout << "The name of person is = " << name << endl;
    }
};
class Student : public Person
{
private:
    float marks;

public:
    void getdata()
    {
        Person::getdata();
        cout << "Enter the marks of student " << endl;
        cin >> marks;
    }
    void showdaata()
    {
        Person::showdaata();
        cout << "The marks of student  is = " << marks << endl;
    }
};
class Teacher : public Person
{
private:
    int pub;

public:
    void getdata()
    {
        Person::getdata();
        cout << "Enter the publications of teacher " << endl;
        cin >> pub;
    }
    void showdaata()
    {

        Person::showdaata();
        cout << "The publications of teacher is = " << pub << endl;
    }
};

int main()
{

    Teacher t1;

    // student s1;
    // s1.getdata();
    t1.getdata();

    // s1.showdaata();
    t1.showdaata();
    return 0;
}
