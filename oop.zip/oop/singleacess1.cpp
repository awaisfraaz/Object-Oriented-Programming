/// Separate put() and get() functions
#include <iostream>
using namespace std;

const int SIZE = 10;
class Array
{
private:
    int arr[SIZE];

public:
//CONSTRUCTORS
    Array()
    {
        for (int i = 0; i < SIZE; i++)
        {
            arr[i] = 0;
        }
    }
    //Return by reference
    int &SingleAccess(int ind)
    {
        if (ind < 0 || ind >= SIZE)
        {
            cout << "\nIndex out of bounds" << endl;
            exit(1);
        }
        return arr[ind];
    }
};
int main()
{
    Array obj;
    for (int i = 0; i < SIZE; i++)
    {
        obj.SingleAccess(i) = i * 10;
    }

    for (int i = 0; i < SIZE; i++)
    {
        int x = obj.SingleAccess(i);
        cout << "value at " << i << " index is " << x << endl;
    }

    return 0;
}