#include <iostream>
using namespace std;
class Vehicle
{
protected:
    int brand;

public:
    int chasis;
    int model;

    void show()
    {
        cout << "i am runing" << endl;
    }
};
class Bus : public Vehicle
{
public:
    void show()
    {
        // Vehicle::show();
        cout << "ALLAH ap ko pass kr dy" << endl;
    }
};
int main()
{
    Bus b;
    b.show();
    return 0;
}