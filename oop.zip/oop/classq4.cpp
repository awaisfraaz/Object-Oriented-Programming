#include <iostream>
#include <string>
using namespace std;
class person
{
private:
    int pid;
    string pname;
    int psalary;

public:
    void getdata()
    {
        cout << "Enter the person id ";
        cin >> pid;
        cout << "Enter the name person ";
        cin >> pname;
        cout << "Enter the salary of a person";
        cin >> psalary;
    }
    void setdata(int id, string name, int salary)
    {
        pid = id;
        pname = name;
        psalary = salary;
    }
    void showdata()
    {
        cout << "The id is  =  " << pid << endl;
        cout << "The name is =  " << pname << endl;
        cout << "The salary is = " << psalary << endl;
    }
    int getsalary()
    {
        return psalary;
    }
};
int main()
{
    person obj1, obj2, obj3;
    cout << "FOR OBJ1" << endl;
    obj1.getdata();
    obj2.setdata(3, "ali", 20000);
    cout << "FOR OBJ2" << endl;
    obj3.getdata();

    obj1.showdata();
    obj2.showdata();
    obj3.showdata();
 
     person highestsalary;

    if (obj1.getsalary() >= obj2.getsalary() && obj1.getsalary() >= obj3.getsalary())
    {

        highestsalary = obj1;
    }
    else if (obj2.getsalary() >= obj1.getsalary()&& obj2.getsalary() >= obj3.getsalary())
    {

        highestsalary = obj2;
    }
    else
    {
        highestsalary = obj3;
    }
    cout << "The details of highest salary of a object is"  << endl;
    highestsalary.showdata();

   
    return 0;
}