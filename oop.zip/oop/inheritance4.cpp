#include <iostream>
using namespace std;
class Base
{
private:
    int pribase;

protected:
    int probase;

public:
    int pubbase;
};
class Drive1 : public Base
{
private:
    void priDrive1()
    {
        /// pribase = 12;
        probase = 12; ///(protected)
        pubbase = 12; ///(public)
    }

protected:
    void proDrive1()
    {
    }

public:
    void pubDrive1()
    {
    }
};
class Drive2 : public Base
{
private:
    void priDrive2()
    {
        /// pribase = 12;

        probase = 12; ///(private)
        pubbase = 12; ///(private)
    }

protected:
    void proDrive2()
    {
    }

public:
    void pubDrive2()
    {
        cout<<"The pubbase of drive 2 is"<<pubbase;
    }
};
class Drive3 : private Drive2
{
private:
    void priDrive3()
    {
        

    }

protected:
    void proDrive3()
    {
    }

public:
     
    void pubDrive3()
    {
                /// pribase = 12;
        /// probase = 12;   ///(private)
///        pubbase = 12;   ///(private)
      cout<<"enter the drive 2 pybbase ";
      cin>>Drive2::pubbase;
        Drive2::proDrive2(); /// (private)
        Drive2::pubDrive2(); /// (private)
      
    }
};
int main()
{
    Drive3 d;

    d.pubDrive3();
    Drive2 d1;
    d1.pubDrive2();
        return 0;
}