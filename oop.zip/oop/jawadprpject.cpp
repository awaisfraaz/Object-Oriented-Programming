#include <iostream>
#include <fstream>
using namespace std;
const int SIZE = 20;
struct product {
	char pname[100];
	float price, quantity, id;
};
struct customer {
	char name[100], adrs[100], phone_no[100];
	float balance, id;
};
struct installment {
	float number,amount,interest_rate,paid,balance;
};
int totalp = 0,totalc = 0,totali = 0,countc = 0,countp = 0,counti = 0, gc=0, gp=0, gi=0;
void getcus(customer data[SIZE]) {
	ifstream read;
	read.open("customer.txt");
	while (read >> data[gc].id >> data[gc].name >> data[gc].adrs >> data[gc].phone_no >> data[gc].balance) {
		gc++;
	}
	read.close();
}
void getprod(product data1[SIZE]) {
	ifstream read;
	read.open("product.txt");
	while (read >> data1[gp].id >> data1[gp].pname >> data1[gp].price >> data1[gp].quantity) {
		gp++;
	}
	read.close();
}
void getinsta(installment data2[SIZE]) {
	ifstream read;
	read.open("installment.txt");
	while (read >> data2[gi].number >> data2[gi].amount >> data2[gi].interest_rate >>
	        data2[gi].paid >> data2[gi].balance) {
		gi++;
	}
	read.close();
}
void addcustomer (customer data[SIZE]) {
	int i = 0;
	do {
		cout << "ENTER DATA OF CUSTOMER\n\n";
		cout << "Name of customer ";
		cin.ignore();
		cin.get (data[countc].name, 100);
		cout << "Address of the customer ";
		cin.ignore();
		cin.get (data[countc].adrs, 100);
		cout << "Phone number of the customer ";
		cin.ignore();
		cin.get (data[countc].phone_no, 100);
		cout << "Customer's balance ";
		cin >> data[countc].balance;
		cout << "Customer's ID ";
		cin >> data[countc].id;
		cout << "New customer added sucessfully. Press 1 to add more ";
		countc++;
		cin >> i;
	} while (i == 1);
	totalc += countc;
}
void addproduct (product data1[SIZE]) {
	int i = 0;
	do {
		cout << "\t\tENTER DATA OF PRODUCT\n\n";
		cout << "Name of product ";
		cin.ignore();
		cin.get (data1[countp].pname, 100);
		cout << "Price of the product ";
		cin>>data1[countp].price;
		cout << "Quantity of product ";
		cin>>data1[countp].quantity;
		cout << "Product's ID ";
		cin >> data1[countp].id;
		cout << "New product added sucessfully. Press 1 to add more ";
		countp++;
		cin >> i;
	} while (i == 1);
	totalp += countp;
}
void addinstallment(installment data2[SIZE]) {
	cout << "\t\tENTER DATA OF INSTALLMENT\n\n";
	cout << "Installment number ";
	cin>>data2[totali].number;
	cout << "Principal amount ";
	cin>>data2[totali].amount;
	cout << "Interest Rate ";
	cin>>data2[totali].interest_rate;
	cout << "Paid ";
	cin>>data2[totali].paid;
	cout << "Product's ID ";
	counti++;
	data2[totali].balance = data2[totali].amount
	                        * (1 + data2[totali].interest_rate / 100)
	                        - data2[totali].paid;

	totali += counti;
	cout << "Installment added successfully.\n";
}
void displaycustomer (customer data[SIZE],product data1[SIZE],installment data2[SIZE]) {
	getcus(data);
	int i=0;
	while(gc > 0) {
		cout << "\nData of customer " << i + 1 << endl;
		cout << "NAME: " << data[i].name << endl;
		cout << "PHONE NUMBER: " << data[i].phone_no << endl;
		cout << "ADDRESS: " << data[i].adrs << endl;
		cout << "BALANCE: " << data[i].balance << endl << endl;
		cout << "ID: " << data[i].id << endl << endl;
		i++;
		gc--;
	}
}
void displayproduct (product data1[SIZE]) {
	getprod(data1);
	int i=0;
	while(gp > 0) {
		cout << "\nData of product " << i + 1 << endl;
		cout << "NAME: " << data1[i].pname << endl;
		cout << "PRICE: " << data1[i].price << endl;
		cout << "QUANTITY: " << data1[i].quantity << endl;
		cout << "ID: " << data1[i].id << endl << endl;
		gp--;
		i++;
	}
}
void displayinstallment(installment data2[SIZE]) {
	cout << "Installment\tPrincipal\tInterest Rate\tAmount Paid\tBalance\n";
	getinsta(data2);
	int i=0;
	while(gi > 0) {
		cout << data2[i].number << "\t\t"
		     << data2[i].amount << "\t\t"
		     << data2[i].interest_rate << "\t\t"
		     << data2[i].paid << "\t\t"
		     << data2[i].balance << "\n";
		gi--;
	}
}
void updatecustomer (customer data[SIZE]) {
	int id, i = 0;
	ifstream in;
	in.open("customer.txt");
	cout << "The id you wanna update ";
	cin >> id;
	for (int i = 0; i < totalc; i++) {
		if (id == data[i].id) {
			cout << "NAME: " << data[i].name << endl;
			cout << "PHONE NUMBER: " << data[i].phone_no << endl;
			cout << "ADDRESS: " << data[i].adrs << endl;
			cout << "BALANCE: " << data[i].balance << endl << endl;
			cout << "ID: " << data[i].id << endl << endl;
			cout << "Enter New Data \n";
			cin.ignore();
			cout << "Name of customer ";
			cin.ignore();
			cin.get (data[countc].name, 100);
			cout << "Address of the customer ";
			cin.ignore();
			cin.get (data[countc].adrs, 100);
			cout << "Phone number of the customer ";
			cin.ignore();
			cin.get (data[countc].phone_no, 100);
			cout << "Customer's ID ";
			cin >> data[countc].id;
		} else if (i == totalc) {
			cout << "No such record found " << endl;
		}
	}
}

void updateproduct (product data1[SIZE]) {
	int id, i = 0;
	ifstream in;
	in.open("product.txt");
	cout << "The id you wanna update ";
	cin >> id;
	for (int i = 0; i < totalc; i++) {
		if (id == data1[i].id) {
			cout << "NAME: " << data1[i].pname << endl;
			cout << "PRICE: " << data1[i].price << endl;
			cout << "QUANTITY: " << data1[i].quantity << endl;
			cout << "ID: " << data1[i].id << endl << endl;
			cout << "Enter New Data \n";
			cin.ignore();
			cout << "Name of product ";
			cin.ignore();
			cin.get (data1[countp].pname, 100);
			cout << "Price of the product ";
			cin>>data1[countp].price;
			cout << "Quantity of product ";
			cin>>data1[countp].quantity;
			cout << "Product's ID ";
			cin >> data1[countp].id;
		} else if (i == totalp) {
			cout << "No such record found " << endl;
		}
	}
}
void updateinstallment (installment data2[SIZE]) {
	int id, i = 0;
	ifstream in;
	in.open("installment.txt");
	cout << "The number you wanna update ";
	cin >> id;
	for (int i = 0; i < totali; i++) {
		if (id == data2[i].number) {
			cout << "NUMBER: " << data2[i].number << endl;
			cout << "PRINCIPAL AMOUNT: " << data2[i].amount << endl;
			cout << "INTEREST RATE: " << data2[i].interest_rate << endl;
			cout << "PAID: " << data2[i].paid << endl << endl;
			cout << "BALANCE: " << data2[i].balance << endl << endl;
			cout << "Enter New Data \n";
			cout << "Number ";
			cin>>data2[counti].number;
			cout << "Principal amount ";
			cin>>data2[counti].amount;
			cout << "Interest rate ";
			cin >> data2[counti].interest_rate;
			cout << "Paid ";
			cin>>data2[counti].paid;
			cout << "Balance ";
			cin >> data2[counti].balance;
		} else if (i == totali) {
			cout << "No such record found " << endl;
		}
	}
}
void delcustomer (customer data[SIZE]) {
	int choice;
	cout << "---> 1 - To Delete any specific data " << endl;
	cout << "---> 0 - To Exit " << endl;
	cin >> choice;
	switch (choice) {
		case 1: {
			int id, i = 0;
			ifstream in;
			in.open("customer.txt");
			cout << "The id you wanna delete \n    ";
			cin >> id;
			for (int i = 0; i < totalc; i++) {
				if (id == data[i].id) {
					for (int j = i; j < totalc; j++) {
						cin.ignore();
						data[j].name[100] = data[j + 1].name[100];
						data[j].phone_no[100] = data[j + 1].phone_no[100];
						data[j].id = data[j + 1].id;
						data[j].adrs[100] = data[j + 1].adrs[100];
						data[j].balance = data[j + 1].balance;
						totalc--;
						cout << "Customer deleted " << endl;
						break;
					}
					if (i == totalc) {
						cout << "No such record found " << endl;
					}
				}
			}
			break;
		}
		case 0: {
			break;
		}
		default: {
			cout << "Enter a correct value " << endl;
			break;
		}
	}
}
void delproduct (product data1[SIZE]) {
	int choice;
	cout << "---> 1 - To Delete any specific data " << endl;
	cout << "---> 0 - To Exit " << endl;
	cin >> choice;
	switch (choice) {
		case 1: {
			int id, i = 0;
			ifstream in;
			in.open("product.txt");
			cout << "The id you wanna delete \n    ";
			cin >> id;
			for (int i = 0; i < totalp; i++) {
				if (id == data1[i].id) {
					for (int j = i; j < totalp; j++) {
						cin.ignore();
						data1[j].pname[100] = data1[j + 1].pname[100];
						data1[j].price = data1[j + 1].price;
						data1[j].quantity = data1[j + 1].quantity;
						data1[j].id = data1[j + 1].id;
						totalp--;
						cout << "Product deleted " << endl;
						break;
					}
					if (i == totalp) {
						cout << "No such record found " << endl;
					}
				}
			}
			break;
		}
		case 0: {
			break;
		}
		default: {
			cout << "Enter a correct value " << endl;
			break;
		}
	}
}
void storecustomer(customer data[SIZE]) {
	addcustomer(data);
	ofstream store;
	store.open("customer.txt", ios::app);
	for (int i = 0; i < countc ; i++) {
		store << data[i].id << " " << data[i].name << " " << data[i].adrs << " "
		      << data[i].phone_no << " " << data[i].balance << endl;
	}
	store.close();
}
void storeproduct(product data1[SIZE]) {
	addproduct(data1);
	ofstream store;
	store.open("product.txt", ios::app);
	for (int i = 0; i < countp ; i++) {
		store << data1[i].id << " " << data1[i].pname << " " << data1[i].price << " "
		      << data1[i].quantity << endl;
	}
	store.close();
}
void storeinstallment(installment data2[SIZE]) {
	addinstallment(data2);
	ofstream store;
	store.open("installment.txt", ios::app);
	for (int i = 0; i < counti ; i++) {
		store << data2[i].number << " " << data2[i].amount << " " << data2[i].interest_rate << " "
		      << data2[i].paid << " " << data2[i].balance << endl;
	}
	store.close();
}
void store(customer data[SIZE],product data1[SIZE],installment data2[SIZE]) {
	int ch;
	cout<<" 1 - Add customer \n";
	cout<<" 2 - Add product \n";
	cout<<" 2 - Add installment \n";
	cout<<" 4 - Exit \n";
	cin>>ch;
	switch(ch) {
		case 1: {
			storecustomer(data);
			break;
		}
		case 2: {
			storeproduct(data1);
			break;
		}
		case 3: {
			storeinstallment(data2);
			break;
		}
		case 4: {
			break;
		}
		default: {
			cout<<"Invalid choice "<<endl;
			break;
		}
	}
}
void manage (customer data[SIZE],product data1[SIZE],installment data2[SIZE]) {
	int ch;
	cout << " 1 - Store data \n";
	cout << " 2 - Update customer \n";
	cout << " 3 - Delete customer \n";
	cout << " 4 - Display customer \n";
	cout << " 5 - Update product \n";
	cout << " 6 - Delete product \n";
	cout << " 7 - Display product \n";
	cout << " 8 - Update installment \n";
	cout << " 9 - Display data \n";
	cout << " 10 - Exit \n";
	cin >> ch;
	switch (ch) {
		case 1: {
			store(data,data1,data2);
			break;
		}
		case 2: {
			updatecustomer (data);
			break;
		}
		case 3: {
			delcustomer (data);
			break;
		}
		case 4: {
			displaycustomer (data,data1,data2);
			break;
		}
		case 5: {
			updateproduct (data1);
			break;
		}
		case 6: {
			delproduct (data1);
			break;
		}
		case 7: {
			displayproduct (data1);
			break;
		}
		case 8: {
			updateinstallment (data2);
			break;
		}
		case 9: {
			displayinstallment (data2);
			break;
		}
		case 10: {
			break;
		}
		default: {
			cout << "\aInvalid input " << endl;
			break;
		}
	}
}
void report(customer data[SIZE],product data1[SIZE],installment data2[SIZE]) {
	int i = 0;
	ifstream in;
	in.open("customer.txt");
	in.open("product.txt");
	in.open("installment.txt");
	while((in >> data[i].id >> data[i].name >> data[i].adrs >> data[i].phone_no >> data[i].balance)and
	        (in >> data1[i].id >> data1[i].pname >> data1[i].price >> data1[i].quantity)and
	        (in >> data2[i].number >> data2[i].amount >> data2[i].interest_rate >> data2[i].paid >> data2[i].balance)) {
		cout << "ID\tName\tProduct\tPrice-Name\tInstallments" << endl;
		for (int i = 0; i < countc; i++) {
			cout << data[i].id << "\t"
			     << data[i].name << "\t"
			     << data1[i].pname << "\t"
			     << data1[i].price << "\t"
			     << data2[i].balance << endl;
		}
	}
}
void searchProduct(product data1[SIZE]) {
	int i = 0,id;
	ifstream in;
	in.open("product.txt");
	cout << "Enter porduct id: ";
	cin >> id;
	while (in >> data1[i].id >> data1[i].pname >> data1[i].price >> data1[i].quantity) {
		if (data1[i].id == id) {
			cout << data1[i].id << "\t";
			cout << data1[i].pname << "\t";
			cout << data1[i].price << "\t";
			cout << data1[i].quantity << endl;
		}
	}
}
void searchCustomer(customer data[SIZE]) {
	string id;
	int i = 0;
	ifstream in;
	in.open("customer.txt");
	cout << "Enter customer name: ";
	cin >> id;
	while (in >> data[i].id >> data[i].name >> data[i].adrs >> data[i].phone_no >> data[i].balance) {
		if (data[i].name == id) {
			cout << data[i].id << "\t";
			cout << data[i].name << "\t";
			cout << data[i].phone_no << "\t";
			cout << data[i].adrs << "\t";
			cout << data[i].balance << endl;
		}
	}
}
void search(customer data[SIZE],product data1[SIZE]) {
	int choice;

	cout << "1. Search By Customer" << endl;
	cout << "2. Search By Product" << endl;
	cout << "3. Exit\n";
	cin >> choice;
	switch (choice) {
		case 1: {
			searchCustomer(data);
			break;
		}
		case 2: {
			searchProduct(data1);
			break;
		}
		case 3: {
			break;
		}
		default:
			cout << "Invalid choice! Try again." << endl;
	}
}
int main () {
	int choice;
	int exit = 0;
	customer data[20];
	product data1[20];
	installment data2[20];
	do {
		cout << " 1 - Manage Data " << endl ;
		cout << " 2 - Search " << endl ;
		cout << " 3 - Report " << endl ;
		cout << " 0 - Exit " << endl ;
		cin >> choice;
		switch (choice) {
			case 1: {
				manage (data,data1,data2);
				break;
			}
			case 2: {
				search (data,data1);
				break;
			}
			case 3: {
				report (data,data1,data2);
				break;
			}
			case 0: {
				cout << "Your program ended successfully \n";
				exit = 1;
				break;
			}
			default: {
				cout << "\aIncorrect choice \n";
				break;
			}
		}
	} while (exit == 0);
	return 0;
}