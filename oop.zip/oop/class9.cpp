#include<iostream>
using namespace std;
class TEST
{
  private:
  int testcode;
  string description;
  int nocandidate;
  int centerreqd;
  CALCANTR()
};
int main ()
{
    return 0;
}